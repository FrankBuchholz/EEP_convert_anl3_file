# Projekt: EEP_convert_anl3_file

Dieses Projekt enthält verschiedene Programme zur Analyse, Darstellung und Konvertierung von Gleisplänen von EEP sowie zur Live-Anzeige einer laufenden EEP-Anlage.

| Programm | Zweck | Dokumentation |
| --- | --- | --- |
| `EEP_Gleisplan.html` | Gleisplan einer Anlage im Browser, optional mit Live-Daten | dieser Text |
| `EEP_Inventar.html` | Inventarlisten einer Anlage | dieser Text |
| `EEP_Signale.html` | Signalstellungen | dieser Text |
| `EEP_Export_Bridge.html` + `EepExport.lua` | Live-Zustand einer laufenden Anlage (Züge, Signale, Weichen, Zeit, Wetter) | [`EEP_Export_Bridge.md`](EEP_Export_Bridge.md) |
| Webserver-Skripte (IIS, Python, Node.js) | liefern `eep_export.json` und `.anl3` an andere Rechner aus | [`README_Web_Server.md`](README_Web_Server.md) |

Die Programme können direkt mit den angegebenen Links im Browser (Chrome, Firefox oder MS Edge) gestartet werden. In diesem Fall ist eine aktive Internetverbindung notwendig.
Alternativ kann das Archiv [`dist/EEP_convert_anl3_file.zip`](https://github.com/FrankBuchholz/EEP_convert_anl3_file/raw/master/dist/EEP_convert_anl3_file.zip) auf [GitHub](https://github.com/FrankBuchholz/EEP_convert_anl3_file) in einem beliebigen Verzeichnis entpackt werden. Dann können die Programme lokal gestartet werden wobei keine Internetverbindung benötigt wird.

## Programm: EEP_Gleisplan.html

Der Gleisplan zu einer EEP-Anlage wird im Browser angezeigt.

Solche EEP-Anlagen sind z.B. hier zu finden:  
[https://www.eepforum.de/filebase/category-file-list/39-kostenlose-anlagen-ab-eep-7/](https://www.eepforum.de/filebase/category-file-list/39-kostenlose-anlagen-ab-eep-7/ "Kostenlose Anlagen ab EEP 7")

### Aufruf

[https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Gleisplan.html](https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Gleisplan.html "EEP_Gleisplan.html")

### Mausfunktionen

Verschieben: Klick+Halten+Bewegen  
An der Stelle des Cursors hineinzoomen: Doppelklick  
Herauszoomen: <kbd>&#x21E7; Shift</kbd>+Doppelklick  
Details anzeigen: Klick auf Gleis, Symbol, Text oder (bei Live-Anzeige) Zug

- wenn zusammen mit <kbd>&#x21E7; Shift</kbd>, dann wird jeweils ein neues Popup geöffnet
- wenn zusammen mit <kbd>alt</kbd>, dann wird zusätzlich der Code aus der Anlage-Datei für dieses Objekt angezeigt (bei Zügen: die Liste der Fahrzeuge)

### Tastaturfunktionen

<kbd>&larr;</kbd> <kbd>&uarr;</kbd> <kbd>&rarr;</kbd> <kbd>&darr;</kbd> : Verschieben der Graphik (wenn zusammen mit <kbd>&#x21E7; Shift</kbd>, dann jeweils um eine halbe Seite)  
<kbd>+</kbd> <kbd>-</kbd> : Zoomen

### Interaktive Funktionen

Wechsel zwischen vertikalen und horizontaler Ausrichtung (Fullscreen mit <kbd>F11</kbd>)  
Zoom-in, -out, -reset  
Auswahl der anzuzeigenden Gleissysteme und von Informationen wie Texten oder Marker  
Aktuelles Darstellung als Bild (`.png`/`.jpg`/`.svg`) speichern  
Gleisplan auf bestimmtes Gleis, bzw. das Gleis eines Signals oder Weiche positionieren  
Die Positionierung ist auch über das Inventar-Programm möglich!  
Einstellung der Linienbreite und der Schriftgröße  
Auswahl der Gleise mit minimalem und maximalen Höhenfilter  
Farben der Gleissysteme anpassen  
Anzeige der Fahrstraßen (alle bzw. von bestimmten Start-Signalen oder zu bestimmten Ende-Signalen)  
Laden der Anlage-Datei per Datei-Auswahl, Drag&Drop oder URL (Eingabefeld **URL laden** bzw. Aufruf mit `EEP_Gleisplan.html?url=<Adresse der .anl3-Datei>`)  
Live-Anzeige von Zügen sowie Signal- und Weichenstellungen einer laufenden EEP-Anlage mit Infobox zu Zügen und Fahrzeugen (siehe Programm `EEP_Export_Bridge.html`)

### Tipp zum Export als svg

Die Export-Funktion im Programm exportiert den gezeigten Ausschnitt der svg-Graphik.
Alternativ kann man auch das Entwickler-Tool des Browsers verwenden, um die gesamte svg-Graphik zu exportieren:

- Google Chrome:
  - Rechts-Klick in der Graphik &rarr; Inspect <kbd>Ctrl+Shift+I</kbd> &rarr; Das svg-Element wird im neuen Fenster (DevTools) blau hinterlegt angezeigt &rarr; Rechts-Klick auf diesem Element &rarr; Copy &rarr; Copy Element

- Firefox:
  - Rechts-Klick in der Graphik &rarr; Element untersuchen &rarr; Das svg-Element wird im neuen Fenster (DevTools) blau hinterlegt angezeigt &rarr; Rechts-Klick auf diesem Element &rarr; Kopieren &rarr; Äußeres HTML

Nun kann man das svg-Element aus der Zwischenablage in ein leeres Textdokument pasten und z.B. als .svg-Datei speichern.

### Referenz

Diskussionbeitrag im [EEP-Forum](https://www.eepforum.de/forum/thread/26770-eep-gleisplan-im-browser-anzeigen-javascript-projekt).

### Technik

Dieses Programm nutzt die Javascript-Funktion [`DOMParser`](https://www.w3schools.com/xml/xml_parser.asp) um eine `.anl3`-Datei von EEP, die aus [XML](https://www.w3schools.com/xml/xml_tree.asp) aufgebaut ist, zu interpretieren und in das [Document Object Model (DOM)](https://www.w3schools.com/xml/xml_dom.asp) umzuwandeln.

Anschließend wird dynamisch mit Javascript die Graphik des Gleisplanes mit [SVG](https://www.w3schools.com/html/html5_svg.asp)-Befehlen aufgebaut. Die Formatierung der graphischen Elemente erfolgt getrennt von der Definition der Graphik mit der SVG-Variante von [CSS](https://www.w3schools.com/html/html_css.asp).

Der Browser kann solche SVG-Graphiken direkt anzeigen. Zusätzlich werden die Bibliotheken [`svg-pan-zoom`](https://github.com/ariutta/svg-pan-zoom) zum Verschieben und Zoomen und [`toolwindow`](https://github.com/fluffynuts/toolwindow) zur Anzeige von Popups verwendet.

Die automatische Größenanpassung des SVG-Elements im Brower zur Nutzung des gesamten restlichen Bildschirmbereiches erfolgt mit [`flex`](https://www.w3schools.com/css/css3_flexbox.asp).

Die Speicherung der Einstellungen erfolgt automatisch mit [`localStorage`](https://www.w3schools.com/html/html5_webstorage.asp).

Der Fortschrittsbalken beim Laden und Verarbeiten von (großen) Dateien wird mit `Promise` / `requestAnimationFrame` und diversen Schritten bei der Verarbeitung realisiert. Leider unterstützt der Internet Explorer diese Funktion und diverse andere, moderne Sprachkonstrukte nicht und kann daher gar nicht verwendet werden. Die einzig empfohlenen Browser sind daher Google Chrome (bzw. diejenigen Browser, die auf Chomium basieren) und Firefox.

Die interaktive Einstellung der Linien- und Textbreite wird über dynamische Anpassung der CSS-Variablen in den SVG-CSS-Regeln realisiert.

Der doppelte Schieberegler für den Höhenfilter basiert auf [multirange](https://leaverou.github.io/multirange/).  
Der Filter wird über dynamische Anpassung der CSS-Klassen von SVG-Gruppenelemente realisiert.

Die Interaktion mit dem Inventar-Programm und der Export Bridge erfolgt über [`BroadcastChannel`](https://developer.mozilla.org/de/docs/Web/API/BroadcastChannel).

Das Laden der Anlage-Datei von einer URL erfolgt mit `fetch`. Bei einer URL auf einem anderen Server muss dieser CORS-Zugriffe erlauben; `file://` funktioniert nicht.

In 2026 wurden mit Hilfe der Claude AI mehrere Korrekturen und Performance-Verbesserungen erarbeitet.

### Abhängigkeiten

Das Programm verwendet die GitHub-Bibliotheken [`svg-pan-zoom`](https://github.com/ariutta/svg-pan-zoom) und [`toolwindow`](https://github.com/fluffynuts/toolwindow).

---

## Programm: EEP_Inventar.html

Anzeige einer Inventarliste zu einer EEP-Anlage.

### Aufruf

[https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Inventar.html](https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Inventar.html "EEP_Inventar.html")

Zur Zeit wird eine Liste der Weichen, Signale, Kontakte, virtuellen Verbindungen, Zugverbände, Depots, Rollmaterialien, Gleisstile, Gleisobjekte und Kameras ausgegeben. Außerdem werden die Gleisbildstellpulte gezeigt. Die Anlage-Datei kann per Datei-Auswahl, Drag&Drop oder URL (Eingabefeld **URL laden** bzw. Aufruf mit `EEP_Inventar.html?url=<Adresse der .anl3-Datei>`) geladen werden. Das Programm kann leicht für andere Daten erweitert werden werden.

### Interaktive Funktionen

Man kann die Tabellen (bei Firefox auch mit Strg+A) mit Copy & Paste in ein Tabellenverarbeitungsprogramm übertragen. Dazu schaltet man am Besten zuvor die Anzeige der Filter-Zeile aus.

Die Tabellen können mit Klicks in die Spaltenüberschriften sortiert werden.

[Filter-Operatoren](https://github.com/koalyptus/TableFilter/wiki/4.-Filter-operators):  
<kbd>&lt;</kbd>, <kbd>&lt;</kbd>, <kbd>=</kbd>, <kbd>&gt;=</kbd>, <kbd>&gt;</kbd>, <kbd>*</kbd>, <kbd>!</kbd> (nicht), <kbd>{</kbd> (beginnt mit), <kbd>}</kbd> (endet mit), <kbd>||</kbd> (oder), <kbd>&amp;&amp;</kbd> (und), <kbd>[empty]</kbd>, <kbd>[nonempty]</kbd>, <kbd>rgx:</kbd> (gefolgt von einer _regular expression_)

Wenn man in einem weiteren Fenster oder einer weiteren Karteikarte des Browsers den Gleisplan für die gleiche EEP-Anlage-Datei öffnet, dann kann man über die Links von Gleisen, Signalen, Weichen oder Kontakten den Gleisplan auf das gewählte Objekt positionieren und das Info-Popup dort öffnen:

- wenn zusammen mit <kbd>&#x21E7; Shift</kbd>, dann wird jeweils ein neues Popup geöffnet
- wenn zusammen mit <kbd>alt</kbd>, dann wird zusätzlich der Code aus der Anlage-Datei für dieses Objekt angezeigt

### Technik

Dieses Programm nutzt die Javascript-Funktion [`DOMParser`](https://www.w3schools.com/xml/xml_parser.asp), um eine`.anl3`-Datei von EEP, die aus [XML](https://www.w3schools.com/xml/xml_tree.asp) aufgebaut ist, zu interpretieren und in das [Document Object Model (DOM)](https://www.w3schools.com/xml/xml_dom.asp) umzuwandeln.

Zusätzlich wird die GitHub-Bibliothek [`TableFilter`](https://github.com/koalyptus/TableFilter) verwendet, um interaktive Funktionen zur Anzeige der Tabellen anzubieten.

Die Interaktion mit dem Gleisplan-Programm erfolgt über [`BroadcastChannel`](https://developer.mozilla.org/de/docs/Web/API/BroadcastChannel).

### Abhängigkeiten

Das Programm verwendet die GitHub-Bibliothek [`TableFilter`](https://github.com/koalyptus/TableFilter).

---

## Programm: EEP_Signale.html

Anzeige von Signalpositionen.

Die Bedeutung der Signalstellung hängt vom jeweiligen Modell ab – es gibt keine Standards, nicht einmal für die ersten beiden Stellungen.
Beispielsweise gibt es etliche Signale mit der Stellungskombination { 1 : Fahrt, 2 : Halt } und einige andere mit der Stellungskombination { 1 : Halt, 2 : Fahrt } sowie etliche weitere Kombinationen, die mit { 1 : Halt, … } beginnen.
Die Stellungskombination eines Signals kann man der entsprechenden `.ini`-Datei entnehmen. Man erhält diese `.ini`-Dateien im Ordner `C:\EEP15\Resourcen.unp\Signale\Signale` über das EEP-Programm mit „Extras → Ressourcen-Extraktor“).

Die Ausgabe erfolgt gruppiert nach der Stellungskombination. Dafür wird je Kombination eine eindeutige ID generiert.

### Aufruf

[https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Signale.html](https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Signale.html "EEP_Signale.html")

---

## Programm: EEP_Export_Bridge.html (Live-Anzeige einer laufenden EEP-Anlage)

Zeigt den aktuellen Zustand einer laufenden EEP-Anlage im Browser: Züge, Rollmaterial, Signal- und Weichenstellungen, Uhrzeit und Wetter. Die Daten kommen aus dem Lua-Modul `EepExport.lua`, das sie regelmäßig als JSON-Datei (`eep_export.json`) ausgibt.

Die Bridge leitet die Daten zusätzlich an den Gleisplan weiter. Dort werden Züge (mit Infobox bei Klick), Signal- und Weichenstellungen dynamisch dargestellt.

Das Programm, das Lua-Modul und die Live-Erweiterung des Gleisplans wurden in 2026 mit Claude AI erstellt.

### Kurzanleitung

1. **Lua-Modul einbinden:** `EepExport.lua` in den Lua-Ordner von EEP (oder ab EEP 18.1 Plugin 1 in den Anlagenordner) kopieren und im Hauptskript der Anlage laden:

   ```lua
   local EepExport = require("EepExport")

   function EEPMain()
     EepExport.run()
     return 1
   end
   ```

   Signale, Weichen, Depots, Züge und Rollmaterial werden automatisch erkannt. Die Datei `eep_export.json` entsteht im Anlagenordner (sonst im Installationsordner von EEP).
2. **Bridge öffnen** ([Aufruf](https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Export_Bridge.html)) und die JSON-Datei verbinden.
3. **Gleisplan öffnen** (Knopf in der Bridge) und die `.anl3`-Datei **derselben** Anlage laden.

### Wie kommen die Dateien in den Browser?

| Situation | Zugriff auf `eep_export.json` und `.anl3` | Webserver? |
| --- | --- | --- |
| EEP und Browser auf **demselben Rechner** | Bridge: *Datei live verfolgen* (Chrome/Edge); Gleisplan: Datei-Auswahl oder Drag&Drop | nicht nötig |
| EEP und Browser auf **verschiedenen Rechnern** (zweiter PC, Tablet) oder Bridge/Gleisplan **im Web** geöffnet | per URL, z. B. `https://192.168.0.115:3001/eep_export.json` | **ja**: HTTPS-Webserver auf dem EEP-Rechner |

Wenn EEP und Bridge nicht auf demselben Rechner laufen, kann der Browser die JSON-Datei und die `.anl3`-Datei nicht direkt lesen. Dann richtet man auf dem EEP-Rechner einen kleinen Webserver ein, der nur diese beiden Dateitypen ausliefert. Drei Varianten stehen zur Auswahl:

| Variante | Besonderheit |
| --- | --- |
| **IIS** (`Install-IIS-web-server.ps1`) | Windows-Dienst mit Autostart, größter Eingriff ins System |
| **Python** (`Install-Python-web-server.ps1`) | kleiner Eingriff, Start von Hand |
| **Node.js** (`Install-node-web-server.ps1`) | kleiner Eingriff, kein Internet nötig, Start von Hand |

Aufruf (Windows PowerShell als Administrator), Beispiel:

```powershell
.\Install-node-web-server.ps1 -SitePath C:/EEP17 -HttpsPort 3001 -OpenFirewall
```

Einzelheiten, Vor- und Nachteile, Zertifikat und Fehlersuche stehen in [`README_Web_Server.md`](README_Web_Server.md).

### Aufruf

[https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Export_Bridge.html](https://frankbuchholz.github.io/EEP_convert_anl3_file/EEP_Export_Bridge.html "EEP_Export_Bridge.html")

Mit URL-Parameter startet die Abfrage sofort: `EEP_Export_Bridge.html?url=<Adresse der eep_export.json>`

### Dokumentation

- Lua-Modul, Bedienung der Bridge, Zusammenspiel mit dem Gleisplan, Aufbau der JSON-Datei, Fehlersuche: [`EEP_Export_Bridge.md`](https://frankbuchholz.github.io/EEP_convert_anl3_file/README_Export_Bridge.html "EEP_Export_Bridge.md")
- Webserver für den Zugriff von anderen Rechnern: [`README_WebServer.md`](https://frankbuchholz.github.io/EEP_convert_anl3_file/WebServer/README_WebServer.html "README_WebServer.md")

---

# Impressum

(c) Frank Buchholz, 2019
